﻿namespace ChinookDatabase.DataSources._Xml.Schema
{

    partial class ChinookDataSet
    {
    }    
}
